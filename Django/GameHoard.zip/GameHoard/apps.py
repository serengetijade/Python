from django.apps import AppConfig


class GamehoardConfig(AppConfig):
    name = 'GameHoard'
