from django.db import models

platform_choices = [
    ('Board_Game', 'Board Game'),
    ('PlayStation', 'PlayStation'),
    ('Nintendo', 'Nintendo'),
    ('PC', 'PC'),
    ('Puzzle', 'Puzzle'),
    ('XBox', 'XBox'),
    ('Other', 'Other'),
]

rating_choices= [
    ('⭐','⭐'),
    ('⭐⭐','⭐⭐'),
    ('⭐⭐⭐','⭐⭐⭐'),
    ('⭐⭐⭐⭐','⭐⭐⭐⭐'),
    ('⭐⭐⭐⭐⭐','⭐⭐⭐⭐⭐'),
]
class Game(models.Model):
    Name = models.CharField(max_length=80, primary_key=True)
    Platform = models.CharField(max_length=40, choices=platform_choices)
    Rating = models.CharField(max_length=100, choices=rating_choices)
    Notes = models.CharField(max_length=200, default="", null=True)
    #Object manager:
    GameModel = models.Manager()

    ##Define a function or multiple functions that will run when this function is called. This returns the values of the attributes:
    def __str__(self):
        return self.Name + self.Platform + self.Rating + self.Notes