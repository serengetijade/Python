from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.template import loader
from .forms import GameForm
from .models import Game

def GameHoard_home(request):
    #CREATE A RECORD IN THE DB
    form = GameForm(data=request.POST or None)  # Declare a variable 'form' and equate it to the existing Account form (as defined in forms.py); request.Post or None is the default syntax to take any input from the form and put it into this form.
    if request.method == 'POST':
        if form.is_valid():
            form.save()  # Apply save(), a built-in model Manager method to save an object back to the db
            return redirect('GameHoard')    #Redirect to the 'shortcut' (as defined in urls.py)
        else:
            print(form.errors)  # If the form cannot meet the if statement, print the built-in method .errors
            form = GameForm()  # Create an empty version of the form as the variable 'form'.
    #READ the RECORD via the model Manager
    tableContents = Game.GameModel.all()
    content = {         # Declare a variable
        'form': form,   #Pass the 'form' variable back as a dictionary.
        'tableContents': tableContents,
    }
    return render(request, 'GameHoard/GH_index.html', content)

def GameTable(request):
    template = loader.get_template('GameHoard/GH_index.html')
    return HttpResponse(template.render())

#UPDATE A RECORD IN THE DB
def updateGameDB(request, pk):              #When a request is called by the user, it goes to the url 'switchboard', which directs it to a certain method
    pk = pk                                 #pk is the primary key, which gets passed in with the request. #This is where you could convert that value to an integer.
    item = get_object_or_404(Game, pk=pk)   #Assigns a variable to represent this built-in function from the django.shortcuts module. Query the database for the Product (using this built-in function) and it's value at that primary key (which is now converted to an integer).
    form = GameForm(data=request.POST or None, instance=item)    #Invoke the ProductForm, get the information from the form that was sent via the post method (or provide a none value), then use that information to create an instance called item. The instance 'item' then passes back all of its values from its various fields
    if request.method == 'POST':
        if form.is_valid():                 #If the request method is possed, check the form
            form.save()                     #save() is a built-in model Manager method to save an object back to the db
            return redirect('GameHoard')   #Redirect to the 'shortcut' (as defined in urls.py)
        else:
            print(form.errors)
    else:
        content = {
            'form': form,
            'item':item,
            'pk':pk,
        }
        return render(request, 'GameHoard/GH_updateGameDB.html', content)  #Render the page that the user sees. This actually happens first, because nothing prior has had a chance to happen yet.

