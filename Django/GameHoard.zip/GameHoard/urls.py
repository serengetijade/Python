from django.urls import path
from . import views

urlpatterns = [
    #URL syntax: ('pattern to watch for', file.methodName, name="shortcut name")
    path('', views.GameHoard_home, name='GameHoard'),
    path('GameTable/', views.GameTable, name='GameTable'),
    path('<str:pk>/UpdateGame/', views.updateGameDB, name='UpdateGame'),
]