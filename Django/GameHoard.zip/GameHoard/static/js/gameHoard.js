//AddGame FORM VALIDATION
function validateForm() {
    let x = document.forms["GameForm"]["Name"].value;
    if (x == "") {
        alert("The name of the item must be filled out.");
        return false;
    }
}
//STICKY ADDGAME FORM
function openaddGame(){
    document.getElementById("addGame").style.display = "block";
}

function closeForm() {
    document.getElementById("addGame").style.display = "none";
}

//CLOSE FORM IF USER CLICKS OUTSIDE THE CONTACT-CONTAINER WINDOW
document.addEventListener("click",
    function(event){
        if (
          event.target.matches("#addGame")
          )
          {closeForm()}
        }
);

//SHOW GAME LIBRARY AS A TABLE
function showHideElement() {
    //document.getElementById("gameLibraryTable").style.width="100%";
    var peekaboo = document.getElementById("gameLibraryTable");
    if (peekaboo.style.display === "none") {
        peekaboo.style.display = "table";
        var text = document.getElementById("showHideElement").innerHTML ="Hide Your Library List";
    }
    else {
        peekaboo.style.display = "none";
        var text = document.getElementById("showHideElement").innerHTML ="See a List of Your Games";
    }
}
